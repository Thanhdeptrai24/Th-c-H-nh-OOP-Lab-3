﻿#include "PhanSo.h"


int GCD(int a, int b) {
    if (b==0) {
        return a;
    }
    return GCD(b, a % b);
}

void PhanSo::rutGon() {
    // Hàm này rút gọn phân số bằng cách chia tử và mẫu cho ước số chung lớn nhất (gcd).
    // Đảm bảo mẫu số luôn dương. Nếu mẫu số âm, đảo ngược dấu của tử và mẫu.
    // Thuật toán:
    // 1. Tính gcd của tử và mẫu.
    // 2. Chia tử và mẫu cho gcd.
    // 3. Kiểm tra nếu mẫu âm thì đổi dấu cả tử và mẫu.
    int gcd = GCD(iTu, iMau);
    iTu /= gcd;
    iMau /= gcd;
    if (iMau < 0) {
        iTu = -iTu;
        iMau = -iMau;
    }
}

PhanSo::PhanSo() : iTu(0), iMau(1) {
    // Constructor mặc định khởi tạo tử số là 0 và mẫu số là 1.
    // Không có input.
    // Không có output.
}

PhanSo::PhanSo(int Tu, int Mau) : iTu(Tu), iMau(Mau) {
    // Constructor khởi tạo với các giá trị cụ thể.
    // Input: Tu là tử số, Mau là mẫu số.
    // Output: Tạo một đối tượng phân số với tử và mẫu đã cho.
    // Gọi hàm rutGon() để rút gọn phân số ngay sau khi khởi tạo.
    // Thuật toán:
    // 1. Gán giá trị cho iTu và iMau từ input.
    // 2. Gọi hàm rutGon() để đảm bảo phân số được rút gọn.
    rutGon();
}

PhanSo PhanSo::operator+ (const PhanSo& other) const {
    // Toán tử cộng hai phân số.
    // Input: other - đối tượng phân số thứ hai để cộng.
    // Output: Trả về một đối tượng phân số là kết quả của phép cộng.
    // Thuật toán:
    // 1. Tính tử số mới bằng công thức: iTu * other.iMau + other.iTu * iMau.
    // 2. Tính mẫu số mới bằng công thức: iMau * other.iMau.
    // 3. Trả về đối tượng PhanSo mới với tử và mẫu đã tính toán.
    int tu = iTu * other.iMau + other.iTu * iMau;
    int mau = iMau * other.iMau;
    return PhanSo(tu, mau);
}

PhanSo PhanSo::operator- (const PhanSo& other) const {
    // Toán tử trừ hai phân số.
    // Input: other - đối tượng phân số thứ hai để trừ.
    // Output: Trả về một đối tượng phân số là kết quả của phép trừ.
    // Thuật toán:
    // 1. Tính tử số mới bằng công thức: iTu * other.iMau - other.iTu * iMau.
    // 2. Tính mẫu số mới bằng công thức: iMau * other.iMau.
    // 3. Trả về đối tượng PhanSo mới với tử và mẫu đã tính toán.
    int tu = iTu * other.iMau - other.iTu * iMau;
    int mau = iMau * other.iMau;
    return PhanSo(tu, mau);
}

PhanSo PhanSo::operator* (const PhanSo& other) const {
    // Toán tử nhân hai phân số.
    // Input: other - đối tượng phân số thứ hai để nhân.
    // Output: Trả về một đối tượng phân số là kết quả của phép nhân.
    // Thuật toán:
    // 1. Tính tử số mới bằng công thức: iTu * other.iTu.
    // 2. Tính mẫu số mới bằng công thức: iMau * other.iMau.
    // 3. Trả về đối tượng PhanSo mới với tử và mẫu đã tính toán.
    int tu = iTu * other.iTu;
    int mau = iMau * other.iMau;
    return PhanSo(tu, mau);
}

PhanSo PhanSo::operator/ (const PhanSo& other) const {
    // Toán tử chia hai phân số.
    // Input: other - đối tượng phân số thứ hai để chia.
    // Output: Trả về một đối tượng phân số là kết quả của phép chia.
    // Thuật toán:
    // 1. Tính tử số mới bằng công thức: iTu * other.iMau.
    // 2. Tính mẫu số mới bằng công thức: iMau * other.iTu.
    // 3. Trả về đối tượng PhanSo mới với tử và mẫu đã tính toán.
    int tu = iTu * other.iMau;
    int mau = iMau * other.iTu;
    return PhanSo(tu, mau);
}

bool PhanSo::operator== (const PhanSo& other) const {
    // Toán tử so sánh hai phân số.
    // Input: other - đối tượng phân số thứ hai để so sánh.
    // Output: Trả về true nếu hai phân số bằng nhau, false nếu không.
    // Thuật toán:
    // 1. So sánh tử và mẫu của hai phân số.
    return (iTu == other.iTu && iMau == other.iMau);
}

bool PhanSo::operator!= (const PhanSo& other) const {
    // Toán tử so sánh khác.
    // Input: other - đối tượng phân số thứ hai để so sánh.
    // Output: Trả về true nếu hai phân số khác nhau, false nếu bằng nhau.
    // Thuật toán:
    // 1. Sử dụng toán tử == để kiểm tra xem hai phân số có bằng nhau không.
    return !(*this == other);
}

bool PhanSo::operator>= (const PhanSo& other) const {
    // Toán tử so sánh lớn hơn hoặc bằng.
    // Input: other - đối tượng phân số thứ hai để so sánh.
    // Output: Trả về true nếu phân số hiện tại lớn hơn hoặc bằng phân số khác.
    // Thuật toán:
    // 1. So sánh giá trị của hai phân số bằng cách nhân chéo.
    return (iTu * other.iMau >= iMau * other.iTu);
}

bool PhanSo::operator<= (const PhanSo& other) const {
    // Toán tử so sánh nhỏ hơn hoặc bằng.
    // Input: other - đối tượng phân số thứ hai để so sánh.
    // Output: Trả về true nếu phân số hiện tại nhỏ hơn hoặc bằng phân số khác.
    // Thuật toán:
    // 1. So sánh giá trị của hai phân số bằng cách nhân chéo.
    return (iTu * other.iMau <= iMau * other.iTu);
}

bool PhanSo::operator> (const PhanSo& other) const {
    // Toán tử so sánh lớn hơn.
    // Input: other - đối tượng phân số thứ hai để so sánh.
    // Output: Trả về true nếu phân số hiện tại lớn hơn phân số khác.
    // Thuật toán:
    // 1. So sánh giá trị của hai phân số bằng cách nhân chéo.
    return (iTu * other.iMau > iMau * other.iTu);
}

bool PhanSo::operator< (const PhanSo& other) const {
    // Toán tử so sánh nhỏ hơn.
    // Input: other - đối tượng phân số thứ hai để so sánh.
    // Output: Trả về true nếu phân số hiện tại nhỏ hơn phân số khác.
    // Thuật toán:
    // 1. So sánh giá trị của hai phân số bằng cách nhân chéo.
    return (iTu * other.iMau < iMau * other.iTu);
}

std::istream& operator>> (std::istream& in, PhanSo& ps) {
    // Toán tử nhập phân số.
    // Input: Đọc tử và mẫu từ người dùng.
    // Output: Cập nhật đối tượng phân số với các giá trị đã nhập.
    // Thuật toán:
    // 1. Yêu cầu người dùng nhập tử số và mẫu số.
    // 2. Kiểm tra nếu mẫu số bằng 0, thông báo lỗi và gán mẫu = 1.
    // 3. Gọi hàm rutGon() để rút gọn phân số.
    std::cout << "Nhap tu so: ";
    in >> ps.iTu;
    std::cout << "Nhap mau so: ";
    in >> ps.iMau;
    if (ps.iMau == 0) {
        std::cerr << "Mau so khong the bang 0! Dat mau = 1.\n";
        ps.iMau = 1;
    }
    ps.rutGon();
    return in;
}

std::ostream& operator<< (std::ostream& out, const PhanSo& ps) {
    // Toán tử xuất phân số.
    // Output: Xuất phân số ra định dạng thích hợp.
    // Thuật toán:
    // 1. Kiểm tra nếu mẫu số bằng 1, chỉ xuất tử số.
    // 2. Nếu không, xuất tử số và mẫu số theo định dạng tử/mẫu.
    if (ps.iMau == 1) {
        out << ps.iTu;
    }
    else {
        out << ps.iTu << "/" << ps.iMau;
    }
    return out;
}
