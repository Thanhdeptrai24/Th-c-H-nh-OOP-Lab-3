#include <iostream>
#include "PhanSo.h"

int main() {
    PhanSo p1;
    std::cout << "Nhap phan so p1:\n";
    std::cin >> p1;
    std::cout << "P1 = " << p1 << "\n";

    PhanSo p2;
    std::cout << "Nhap phan so p2:\n";
    std::cin >> p2;
    std::cout << "P2 = " << p2 << "\n";


    std::cout << "P1 + P2 = " << p1 + p2 << "\n";
    std::cout << "P1 - P2 = " << p1 - p2 << "\n";
    std::cout << "P1 * P2 = " << p1 * p2 << "\n";
    std::cout << "P1 / P2 = " << p1 / p2 << "\n";

    std::cout << "P1 == P2: " << (p1 == p2 ? "True" : "False") << "\n";
    std::cout << "P1 != P2: " << (p1 != p2 ? "True" : "False") << "\n";
    std::cout << "P1 >= P2: " << (p1 >= p2 ? "True" : "False") << "\n";
    std::cout << "P1 <= P2: " << (p1 <= p2 ? "True" : "False") << "\n";
    std::cout << "P1 > P2: " << (p1 > p2 ? "True" : "False") << "\n";
    std::cout << "P1 < P2: " << (p1 < p2 ? "True" : "False") << "\n";

  
    return 0;
}
