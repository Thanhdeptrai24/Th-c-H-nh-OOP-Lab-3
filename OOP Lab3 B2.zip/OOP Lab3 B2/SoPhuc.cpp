﻿#include "SoPhuc.h"
#include "SoPhuc.h"

SoPhuc::SoPhuc() : dThuc(0), dAo(0) {}

// Constructor khởi tạo số phức với phần thực và phần ảo được chỉ định
// Input: int thuc, int ao - các giá trị cho phần thực và phần ảo
// Output: Một đối tượng SoPhuc với phần thực và phần ảo được khởi tạo
// Thuật toán: Khởi tạo thuộc tính dThuc và dAo với giá trị truyền vào
SoPhuc::SoPhuc(int thuc, int ao) : dThuc(thuc), dAo(ao) {}

// Phép cộng hai số phức
// Input: const SoPhuc& other - số phức khác để cộng
// Output: Một đối tượng SoPhuc đại diện cho tổng của hai số phức
// Thuật toán: Cộng phần thực với phần thực và phần ảo với phần ảo
SoPhuc SoPhuc::operator+(const SoPhuc& other) const {
    return SoPhuc(dThuc + other.dThuc, dAo + other.dAo);
}

// Phép trừ hai số phức
// Input: const SoPhuc& other - số phức khác để trừ
// Output: Một đối tượng SoPhuc đại diện cho hiệu của hai số phức
// Thuật toán: Trừ phần thực với phần thực và phần ảo với phần ảo
SoPhuc SoPhuc::operator-(const SoPhuc& other) const {
    return SoPhuc(dThuc - other.dThuc, dAo - other.dAo);
}

// Phép nhân hai số phức
// Input: const SoPhuc& other - số phức khác để nhân
// Output: Một đối tượng SoPhuc đại diện cho tích của hai số phức
// Thuật toán: Sử dụng công thức nhân số phức:
// thực = thực1 * thực2 - ảo1 * ảo2
// ảo = thực1 * ảo2 + ảo1 * thực2
SoPhuc SoPhuc::operator*(const SoPhuc& other) const {
    int thuc = dThuc * other.dThuc - dAo * other.dAo;
    int ao = dThuc * other.dAo + dAo * other.dThuc;
    return SoPhuc(thuc, ao);
}

// Phép chia hai số phức
// Input: const SoPhuc& other - số phức khác để chia
// Output: Một đối tượng SoPhuc đại diện cho thương của hai số phức
// Thuật toán: Sử dụng công thức chia số phức:
// mau = thực2^2 + ảo2^2
// thực = (thực1 * thực2 + ảo1 * ảo2) / mau
// ảo = (ảo1 * thực2 - thực1 * ảo2) / mau
SoPhuc SoPhuc::operator/(const SoPhuc& other) const {
    int mau = other.dThuc * other.dThuc + other.dAo * other.dAo;
    int thuc = (dThuc * other.dThuc + dAo * other.dAo) / mau;
    int ao = (dAo * other.dThuc - dThuc * other.dAo) / mau;
    return SoPhuc(thuc, ao);
}

// Phép so sánh hai số phức để kiểm tra xem có bằng nhau hay không
// Input: const SoPhuc& other - số phức khác để so sánh
// Output: true nếu hai số phức bằng nhau, false nếu không
// Thuật toán: Kiểm tra xem phần thực và phần ảo có bằng nhau không
bool SoPhuc::operator==(const SoPhuc& other) const {
    return (dThuc == other.dThuc) && (dAo == other.dAo);
}

// Phép so sánh hai số phức để kiểm tra xem có khác nhau hay không
// Input: const SoPhuc& other - số phức khác để so sánh
// Output: true nếu hai số phức khác nhau, false nếu không
// Thuật toán: Gọi hàm so sánh == và trả giá trị ngược lại
bool SoPhuc::operator!=(const SoPhuc& other) const {
    return !(*this == other);
}

// Phương thức nhập số phức từ luồng nhập
// Input: istream& in - luồng nhập
// Output: Luồng nhập sau khi đã đọc giá trị cho số phức
// Thuật toán: Đọc hai giá trị cho phần thực và phần ảo từ luồng
istream& operator>>(istream& in, SoPhuc& sp) {
    in >> sp.dThuc >> sp.dAo;
    return in;
}

// Phương thức xuất số phức ra luồng xuất
// Input: ostream& out - luồng xuất
// Output: Luồng xuất sau khi đã in giá trị số phức
// Thuật toán: In phần thực và phần ảo theo định dạng "a + bi"
ostream& operator<<(ostream& out, const SoPhuc& sp) {
    out << sp.dThuc << " + " << sp.dAo << "i";
    return out;
}
