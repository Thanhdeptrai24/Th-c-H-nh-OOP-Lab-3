#include "NgayThangNam.h"

int main() {
    int nam, thang, ngay;

    std::cout << "Nhap nam: ";
    std::cin >> nam;
    std::cout << "Nhap thang: ";
    std::cin >> thang;
    std::cout << "Nhap ngay: ";
    std::cin >> ngay;

    try {
        NgayThangNam date1(nam, thang, ngay);

        int themNgay;
        std::cout << "Nhap so ngay muon them: ";
        std::cin >> themNgay;

        NgayThangNam date2 = date1 + themNgay;

        int truNgay;
        std::cout << "Nhap so ngay muon tru: ";
        std::cin >> truNgay;

        NgayThangNam date3 = date1 - truNgay;

        std::cout << "Date 1: " << date1 << std::endl;
        std::cout << "Date 2 (date1 + " << themNgay << "): " << date2 << std::endl;
        std::cout << "Date 3 (date1 - " << truNgay << "): " << date3 << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Loi: " << e.what() << std::endl;
    }

    return 0;
}
