#pragma once
#ifndef SOPHUC_H
#define SOPHUC_H

#include <iostream>
using namespace std;

class SoPhuc {
private:
    int dThuc;
    int dAo;

public:
    SoPhuc();
    SoPhuc(int thuc, int ao);
    SoPhuc operator+(const SoPhuc& other) const;
    SoPhuc operator-(const SoPhuc& other) const;
    SoPhuc operator*(const SoPhuc& other) const;
    SoPhuc operator/(const SoPhuc& other) const;
    bool operator==(const SoPhuc& other) const;
    bool operator!=(const SoPhuc& other) const;
    friend istream& operator>>(istream& in, SoPhuc& sp);
    friend ostream& operator<<(ostream& out, const SoPhuc& sp);
};

#endif

