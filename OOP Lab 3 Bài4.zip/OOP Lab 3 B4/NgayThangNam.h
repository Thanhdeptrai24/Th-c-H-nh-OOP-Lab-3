#ifndef NGAYTHANGNAM_H
#define NGAYTHANGNAM_H

#include <iostream>
#include <stdexcept>

class NgayThangNam {
private:
    int iNgay;
    int iThang;
    int iNam;

    bool isLeapYear(int year);
    int daysInMonth(int month, int year);

public:
    NgayThangNam();
    NgayThangNam(int nam, int thang, int ngay);
    int TinhNgay();
    NgayThangNam operator+(int ngay);
    NgayThangNam operator-(int ngay);
    NgayThangNam operator-(NgayThangNam a);
    NgayThangNam operator++();
    NgayThangNam operator--();
    bool operator==(NgayThangNam a);
    bool operator!=(NgayThangNam a);
    bool operator>=(NgayThangNam a);
    bool operator<=(NgayThangNam a);
    bool operator>(NgayThangNam a);
    bool operator<(NgayThangNam a);
    friend std::ostream& operator<<(std::ostream& os, const NgayThangNam& dt);
};

#endif
