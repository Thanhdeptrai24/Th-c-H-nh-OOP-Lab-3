﻿#include "NgayThangNam.h"

// Kiểm tra xem năm có phải năm nhuận hay không
// Input: year - năm cần kiểm tra
// Output: true nếu là năm nhuận, false nếu không
// Thuật toán: Kiểm tra điều kiện chia cho 4, không chia cho 100 hoặc chia cho 400
bool NgayThangNam::isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

// Trả về số ngày trong tháng của năm cụ thể
// Input: month - tháng cần kiểm tra, year - năm tương ứng
// Output: số ngày trong tháng
// Thuật toán: Sử dụng điều kiện để xác định số ngày trong tháng, năm nhuận cho tháng 2
int NgayThangNam::daysInMonth(int month, int year) {
    if (month == 2) {
        return isLeapYear(year) ? 29 : 28;
    }
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        return 30;
    }
    return 31;
}

// Khởi tạo đối tượng NgayThangNam với giá trị mặc định
// Input: không có
// Output: không có
// Thuật toán: Thiết lập giá trị ngày, tháng, năm mặc định
NgayThangNam::NgayThangNam() : iNgay(1), iThang(1), iNam(2000) {}

// Khởi tạo đối tượng NgayThangNam với năm, tháng, ngày cụ thể
// Input: nam - năm, thang - tháng, ngay - ngày
// Output: không có, nhưng có thể ném ngoại lệ nếu giá trị không hợp lệ
// Thuật toán: Kiểm tra tính hợp lệ của ngày, tháng, năm trước khi gán
NgayThangNam::NgayThangNam(int nam, int thang, int ngay) {
    if (thang < 1 || thang > 12 || ngay < 1 || ngay > daysInMonth(thang, nam)) {
        throw std::invalid_argument("Ngay, thang, nam khong hop le!");
    }
    iNam = nam;
    iThang = thang;
    iNgay = ngay;
}

// Tính tổng số ngày từ năm 1900 đến ngày hiện tại
// Input: không có
// Output: tổng số ngày dưới dạng int
// Thuật toán: Tính toán số ngày dựa trên công thức tổng hợp từ ngày, tháng và năm
int NgayThangNam::TinhNgay() {
    return iNgay + (iThang - 1) * 30 + (iNam - 1900) * 365;
}

// Cộng một số ngày vào đối tượng NgayThangNam
// Input: ngay - số ngày cần cộng
// Output: đối tượng NgayThangNam mới sau khi cộng
// Thuật toán: Cộng số ngày vào ngày hiện tại, điều chỉnh tháng và năm nếu cần
NgayThangNam NgayThangNam::operator+(int ngay) {
    NgayThangNam result = *this;
    result.iNgay += ngay;
    while (result.iNgay > result.daysInMonth(result.iThang, result.iNam)) {
        result.iNgay -= result.daysInMonth(result.iThang, result.iNam);
        result.iThang++;
        if (result.iThang > 12) {
            result.iThang = 1;
            result.iNam++;
        }
    }
    return result;
}

// Trừ một số ngày từ đối tượng NgayThangNam
// Input: ngay - số ngày cần trừ
// Output: đối tượng NgayThangNam mới sau khi trừ
// Thuật toán: Giảm số ngày, điều chỉnh tháng và năm nếu cần
NgayThangNam NgayThangNam::operator-(int ngay) {
    NgayThangNam result = *this;
    result.iNgay -= ngay;
    while (result.iNgay <= 0) {
        result.iThang--;
        if (result.iThang <= 0) {
            result.iThang = 12;
            result.iNam--;
        }
        result.iNgay += result.daysInMonth(result.iThang, result.iNam);
    }
    return result;
}

// Trừ một đối tượng NgayThangNam từ đối tượng hiện tại
// Input: a - đối tượng NgayThangNam cần trừ
// Output: đối tượng NgayThangNam mới sau khi trừ
// Thuật toán: Trừ ngày, tháng, năm tương ứng
NgayThangNam NgayThangNam::operator-(NgayThangNam a) {
    return NgayThangNam(iNam - a.iNam, iThang - a.iThang, iNgay - a.iNgay);
}

// Tự động tăng ngày lên một
// Input: không có
// Output: đối tượng NgayThangNam mới sau khi tự tăng
// Thuật toán: Gọi toán tử cộng với 1
NgayThangNam NgayThangNam::operator++() {
    return *this + 1;
}

// Tự động giảm ngày xuống một
// Input: không có
// Output: đối tượng NgayThangNam mới sau khi tự giảm
// Thuật toán: Gọi toán tử trừ với 1
NgayThangNam NgayThangNam::operator--() {
    return *this - 1;
}

// Kiểm tra sự bằng nhau giữa hai đối tượng NgayThangNam
// Input: a - đối tượng NgayThangNam cần so sánh
// Output: true nếu bằng nhau, false nếu không
// Thuật toán: So sánh ngày, tháng, năm
bool NgayThangNam::operator==(NgayThangNam a) {
    return (iNgay == a.iNgay && iThang == a.iThang && iNam == a.iNam);
}

// Kiểm tra sự không bằng nhau giữa hai đối tượng NgayThangNam
// Input: a - đối tượng NgayThangNam cần so sánh
// Output: true nếu không bằng nhau, false nếu bằng nhau
// Thuật toán: Đảo ngược kết quả của toán tử == 
bool NgayThangNam::operator!=(NgayThangNam a) {
    return !(*this == a);
}

// Kiểm tra nếu đối tượng hiện tại lớn hơn hoặc bằng đối tượng khác
// Input: a - đối tượng NgayThangNam cần so sánh
// Output: true nếu lớn hơn hoặc bằng, false nếu không
// Thuật toán: So sánh tổng số ngày của hai đối tượng
bool NgayThangNam::operator>=(NgayThangNam a) {
    return TinhNgay() >= a.TinhNgay();
}

// Kiểm tra nếu đối tượng hiện tại nhỏ hơn hoặc bằng đối tượng khác
// Input: a - đối tượng NgayThangNam cần so sánh
// Output: true nếu nhỏ hơn hoặc bằng, false nếu không
// Thuật toán: So sánh tổng số ngày của hai đối tượng
bool NgayThangNam::operator<=(NgayThangNam a) {
    return TinhNgay() <= a.TinhNgay();
}

// Kiểm tra nếu đối tượng hiện tại lớn hơn đối tượng khác
// Input: a - đối tượng NgayThangNam cần so sánh
// Output: true nếu lớn hơn, false nếu không
// Thuật toán: So sánh tổng số ngày của hai đối tượng
bool NgayThangNam::operator>(NgayThangNam a) {
    return TinhNgay() > a.TinhNgay();
}

// Kiểm tra nếu đối tượng hiện tại nhỏ hơn đối tượng khác
// Input: a - đối tượng NgayThangNam cần so sánh
// Output: true nếu nhỏ hơn, false nếu không
// Thuật toán: So sánh tổng số ngày của hai đối tượng
bool NgayThangNam::operator<(NgayThangNam a) {
    return TinhNgay() < a.TinhNgay();
}

// Xuất đối tượng NgayThangNam ra màn hình
// Input: os - đối tượng std::ostream, dt - đối tượng NgayThangNam cần xuất
// Output: đối tượng std::ostream đã được cập nhật với giá trị ngày tháng năm
// Thuật toán: Ghi ngày, tháng, năm vào stream
std::ostream& operator<<(std::ostream& os, const NgayThangNam& dt) {
    os << dt.iNgay << "/" << dt.iThang << "/" << dt.iNam;
    return os;
}
