﻿#include "SoPhuc.h"

int main() {
    SoPhuc sp1, sp2;
    cout << "Nhap So Phuc Thu Nhat" << endl;
    cin >> sp1;
    cout << "sp1: " << sp1 << endl;
    cout << "Nhap So Phuc Thu Hai" << endl;
    cin >> sp2;
    cout << "sp2 " << sp2 << endl;

    SoPhuc sum = sp1 + sp2;
    SoPhuc difference = sp1 - sp2;
    SoPhuc product = sp1 * sp2;
    SoPhuc quotient = sp1 / sp2;

    cout << "Tong " << sum << endl;
    cout << "Hieu " << difference << endl;
    cout << "Tich: " << product << endl;
    cout << "Thuong: " << quotient << endl;

    if (sp1 == sp2)
        cout << "Hai So Phuc bang nhau:" << endl;
    else
        cout << "Hai So Phuc Khac nhau:" << endl;

    return 0;
}
