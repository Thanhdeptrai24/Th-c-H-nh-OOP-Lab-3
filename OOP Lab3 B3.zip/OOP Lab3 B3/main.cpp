#include <iostream>
#include "ThoiGian.h"

using namespace std;

int main() {
    ThoiGian tg1, tg2;
    cout << "Nhap thoi gian thu nhat (gio, phut, giay): ";
    cin >> tg1;
    cout << "Nhap thoi gian thu hai (gio, phut, giay): ";
    cin >> tg2;

    ThoiGian tong = tg1 + tg2;
    ThoiGian hieu = tg1 - tg2;

    cout << "Tong thoi gian: " << tong << endl;
    cout << "Hieu thoi gian: " << hieu << endl;

    if (tg1 == tg2) {
        cout << "Hai thoi gian bang nhau." << endl;
    }
    else {
        cout << "Hai thoi gian khong bang nhau." << endl;
    }

    return 0;
}
