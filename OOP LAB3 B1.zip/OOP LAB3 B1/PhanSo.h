#pragma once


#include <iostream>
#include <cmath>

class PhanSo {
private:
    int iTu;
    int iMau;

    void rutGon();

public:
    PhanSo();
    PhanSo(int Tu, int Mau);
    PhanSo operator+ (const PhanSo& other) const;
    PhanSo operator- (const PhanSo& other) const;
    PhanSo operator* (const PhanSo& other) const;
    PhanSo operator/ (const PhanSo& other) const;
    bool operator== (const PhanSo& other) const;
    bool operator!= (const PhanSo& other) const;
    bool operator>= (const PhanSo& other) const;
    bool operator<= (const PhanSo& other) const;
    bool operator> (const PhanSo& other) const;
    bool operator< (const PhanSo& other) const;
    friend std::istream& operator>> (std::istream& in, PhanSo& ps);
    friend std::ostream& operator<< (std::ostream& out, const PhanSo& ps);
};

