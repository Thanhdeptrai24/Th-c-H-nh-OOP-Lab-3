﻿#include "ThoiGian.h"

// Khởi tạo thời gian mặc định 0 giờ 0 phút 0 giây.
// Thuật toán: Gán các giá trị iGio, iPhut, iGiay bằng 0.
ThoiGian::ThoiGian() : iGio(0), iPhut(0), iGiay(0) {}

// Khởi tạo thời gian với giờ, phút, giây cho trước.
// Thuật toán: Tính toán giờ, phút, giây từ các tham số đầu vào và điều chỉnh lại giá trị.
ThoiGian::ThoiGian(int Gio, int Phut, int Giay) {
    iGio = Gio + Phut / 60 + Giay / 3600;
    iPhut = (Phut + Giay / 60) % 60;
    iGiay = Giay % 60;
}

// Tính tổng số giây từ giờ, phút và giây.
// Input: Không có.
// Output: Tổng số giây tương ứng với thời gian.
// Thuật toán: Tính tổng số giây bằng công thức: giay = gio * 3600 + phut * 60 + giay.
int ThoiGian::TinhGiay() {
    return iGio * 3600 + iPhut * 60 + iGiay;
}

// Cập nhật thời gian bằng cách cộng hoặc trừ số giây được cung cấp.
// Input: Một số nguyên Giay (có thể âm hoặc dương).
// Output: Cập nhật giờ, phút và giây của đối tượng.
// Thuật toán: Tính tổng số giây hiện tại và giây cần cập nhật, sau đó chuyển đổi lại thành giờ, phút, giây.
void ThoiGian::TinhLaiGio(int Giay) {
    int tongGiay = TinhGiay() + Giay;
    iGio = tongGiay / 3600;
    iPhut = (tongGiay % 3600) / 60;
    iGiay = tongGiay % 60;
}

// Cộng thêm số giây vào thời gian.
// Input: Một số nguyên Giay.
// Output: Trả về đối tượng ThoiGian mới với thời gian đã cộng.
// Thuật toán: Tạo đối tượng mới, cập nhật thời gian bằng cách gọi phương thức TinhLaiGio.
ThoiGian ThoiGian::operator+(int Giay) {
    ThoiGian result = *this;
    result.TinhLaiGio(Giay);
    return result;
}

// Trừ số giây khỏi thời gian.
// Input: Một số nguyên Giay.
// Output: Trả về đối tượng ThoiGian mới với thời gian đã trừ.
// Thuật toán: Tạo đối tượng mới, cập nhật thời gian bằng cách gọi phương thức TinhLaiGio với giá trị âm.
ThoiGian ThoiGian::operator-(int Giay) {
    ThoiGian result = *this;
    result.TinhLaiGio(-Giay);
    return result;
}

// Cộng hai thời gian với nhau.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về đối tượng ThoiGian mới là tổng của hai thời gian.
// Thuật toán: Tạo một đối tượng mới bằng cách cộng từng phần giờ, phút, giây của hai thời gian.
ThoiGian ThoiGian::operator+(ThoiGian a) {
    return ThoiGian(iGio + a.iGio, iPhut + a.iPhut, iGiay + a.iGiay);
}

// Trừ một thời gian khỏi thời gian hiện tại.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về đối tượng ThoiGian mới là hiệu của hai thời gian.
// Thuật toán: Tạo một đối tượng mới bằng cách trừ từng phần giờ, phút, giây của hai thời gian.
ThoiGian ThoiGian::operator-(ThoiGian a) {
    return ThoiGian(iGio - a.iGio, iPhut - a.iPhut, iGiay - a.iGiay);
}

// Tăng thời gian lên 1 giây.
// Input: Không có.
// Output: Trả về đối tượng ThoiGian đã tăng.
// Thuật toán: Gọi phương thức TinhLaiGio với tham số là 1.
ThoiGian ThoiGian::operator++() {
    TinhLaiGio(1);
    return *this;
}

// Giảm thời gian xuống 1 giây.
// Input: Không có.
// Output: Trả về đối tượng ThoiGian đã giảm.
// Thuật toán: Gọi phương thức TinhLaiGio với tham số là -1.
ThoiGian ThoiGian::operator--() {
    TinhLaiGio(-1);
    return *this;
}

// So sánh hai thời gian để kiểm tra xem chúng có bằng nhau hay không.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về true nếu hai thời gian bằng nhau, false nếu không.
// Thuật toán: So sánh tổng số giây của hai thời gian.
bool ThoiGian::operator==(ThoiGian a) {
    return TinhGiay() == a.TinhGiay();
}

// So sánh hai thời gian để kiểm tra xem chúng có khác nhau hay không.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về true nếu hai thời gian không bằng nhau, false nếu bằng nhau.
// Thuật toán: Sử dụng toán tử == để kiểm tra sự bằng nhau.
bool ThoiGian::operator!=(ThoiGian a) {
    return !(*this == a);
}

// So sánh hai thời gian để kiểm tra xem thời gian hiện tại có lớn hơn hoặc bằng thời gian a hay không.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về true nếu thời gian hiện tại lớn hơn hoặc bằng a, false nếu không.
// Thuật toán: So sánh tổng số giây của hai thời gian.
bool ThoiGian::operator>=(ThoiGian a) {
    return TinhGiay() >= a.TinhGiay();
}

// So sánh hai thời gian để kiểm tra xem thời gian hiện tại có nhỏ hơn hoặc bằng thời gian a hay không.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về true nếu thời gian hiện tại nhỏ hơn hoặc bằng a, false nếu không.
// Thuật toán: So sánh tổng số giây của hai thời gian.
bool ThoiGian::operator<=(ThoiGian a) {
    return TinhGiay() <= a.TinhGiay();
}

// So sánh hai thời gian để kiểm tra xem thời gian hiện tại có lớn hơn thời gian a hay không.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về true nếu thời gian hiện tại lớn hơn a, false nếu không.
// Thuật toán: So sánh tổng số giây của hai thời gian.
bool ThoiGian::operator>(ThoiGian a) {
    return TinhGiay() > a.TinhGiay();
}

// So sánh hai thời gian để kiểm tra xem thời gian hiện tại có nhỏ hơn thời gian a hay không.
// Input: Một đối tượng ThoiGian a.
// Output: Trả về true nếu thời gian hiện tại nhỏ hơn a, false nếu không.
// Thuật toán: So sánh tổng số giây của hai thời gian.
bool ThoiGian::operator<(ThoiGian a) {
    return TinhGiay() < a.TinhGiay();
}

// Nhập thời gian từ người dùng.
// Input: Đối tượng ThoiGian tg.
// Output: Cập nhật các thuộc tính iGio, iPhut, iGiay của đối tượng tg.
// Thuật toán: Sử dụng istream để lấy giá trị giờ, phút, giây từ người dùng.
std::istream& operator>>(std::istream& is, ThoiGian& tg) {
    is >> tg.iGio >> tg.iPhut >> tg.iGiay;
    return is;
}

// Xuất thời gian ra màn hình.
// Input: Đối tượng ThoiGian tg.
// Output: Hiển thị giờ, phút và giây của tg.
// Thuật toán: Sử dụng ostream để định dạng và in ra các thành phần của tg.
std::ostream& operator<<(std::ostream& os, const ThoiGian& tg) {
    os << tg.iGio << " gio " << tg.iPhut << " phut " << tg.iGiay << " giay";
    return os;
}
